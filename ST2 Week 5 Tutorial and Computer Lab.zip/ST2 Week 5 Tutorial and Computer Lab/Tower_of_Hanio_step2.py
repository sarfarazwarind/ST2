move_count = 0


def moveDisks(n, fromTower, toTower, auxTower):
    global move_count

    if n == 1:
        move_count += 1
        print(f"  Move disk {n} from {fromTower} to {toTower}")

    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        move_count += 1
        print(f"  Move disk {n} from {fromTower} to {toTower}")
        moveDisks(n - 1, auxTower, toTower, fromTower)


def main():
    global move_count

    n = eval(input("Enter number of disks: "))
    move_count = 0
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    print(f"Number of moves is {move_count}")

main()