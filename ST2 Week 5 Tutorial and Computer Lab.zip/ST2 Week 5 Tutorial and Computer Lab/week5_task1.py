
import timeit
import sys

sys.setrecursionlimit(10000)


#SUM OF NATURAL NUMBERS
# Recursive
def sum_recursive(n):
    if n == 1:
        return 1
    else:
        return n + sum_recursive(n - 1)


# Iterative
def sum_iterative(n):
    total = 0
    for i in range(1, n + 1):
        total += i
    return total


# TEST CASE 2: FIBONACCI SEQUENCE

# Recursive
def fibonacci_recursive(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fibonacci_recursive(n - 1) + fibonacci_recursive(n - 2)

# Iterative
def fibonacci_iterative(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    prev, curr = 0, 1
    for _ in range(2, n + 1):
        prev, curr = curr, prev + curr
    return curr


# TEST CASE 3: FACTORIAL

# Recursive
def factorial_recursive(n):
    if n == 0:
        return 1
    else:
        return n * factorial_recursive(n - 1)

# Iterative
def factorial_iterative(n):
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result

# ============================================================
# BENCHMARKING
# ============================================================
RUNS = 500

print("\n" + "=" * 55)
print("Recursive vs Iterative")
print("=" * 55)

#Sum
print("\nSum of Natural Numbers")
print(f"{'n':>6}  {'Recursive (s)':>16}  {'Iterative (s)':>16}")
print("" * 55)
for n in [5, 10, 25]:
    t_rec  = timeit.timeit(lambda n=n: sum_recursive(n),  number=RUNS)
    t_iter = timeit.timeit(lambda n=n: sum_iterative(n),  number=RUNS)
    faster = "Iterative" if t_iter < t_rec else "Recursive"
    print(f"{n:>6}  {t_rec:>16.6f}  {t_iter:>16.6f}")

#Fibonacci
print("\nFibonacci Sequence")
print(f"{'n':>6}  {'Recursive (s)':>16}  {'Iterative (s)':>16}")
print("-" * 55)
for n in [5, 10, 25]:
    t_rec  = timeit.timeit(lambda n=n: fibonacci_recursive(n), number=RUNS)
    t_iter = timeit.timeit(lambda n=n: fibonacci_iterative(n), number=RUNS)
    faster = "Iterative" if t_iter < t_rec else "Recursive"
    print(f"{n:>6}  {t_rec:>16.6f}  {t_iter:>16.6f}")

#Factorial
print("\nFactorial")
print(f"{'n':>6}  {'Recursive (s)':>16}  {'Iterative (s)':>16}")
print("-" * 55)
for n in [5, 10, 25]:
    t_rec  = timeit.timeit(lambda n=n: factorial_recursive(n), number=RUNS)
    t_iter = timeit.timeit(lambda n=n: factorial_iterative(n), number=RUNS)
    faster = "Iterative" if t_iter < t_rec else "Recursive"
    print(f"{n:>6}  {t_rec:>16.6f}  {t_iter:>16.6f}")