from tkinter import * # Import tkinter
import math

class KochSnowflake:
    def __init__(self):
        window = Tk() # Create a window
        window.title("Koch Snowflake") # Set a title

        self.width = 200
        self.height = 200
        self.canvas = Canvas(window, width=self.width, height=self.height,
                             bg="white")
        self.canvas.pack()
        # Add a label, an entry, and a button to frame1
        frame1 = Frame(window) # Create and add a frame to window
        frame1.pack()

        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        Entry(frame1, textvariable=self.order, justify=RIGHT).pack(side=LEFT)
        Button(frame1, text="Display",
               command=self.display).pack(side=LEFT)

        window.mainloop() # Create an event loop

    def display(self):
        self.canvas.delete("line")
        order = int(self.order.get())
        p1 = [self.width / 2, 50]
        p2 = [50, self.height - 50]
        p3 = [self.width - 50, self.height - 50]
        self.kochCurve(order, p1, p2)
        self.kochCurve(order, p2, p3)
        self.kochCurve(order, p3, p1)

    def kochCurve(self, order, p1, p2):
        if order == 0:
            self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")
        else:
            pA = [p1[0] + (p2[0] - p1[0]) / 3,
                  p1[1] + (p2[1] - p1[1]) / 3]
            pB = [p1[0] + 2 * (p2[0] - p1[0]) / 3,
                  p1[1] + 2 * (p2[1] - p1[1]) / 3]
            dx = pB[0] - pA[0]
            dy = pB[1] - pA[1]
            pC = [pA[0] + dx / 2 - dy * math.sqrt(3) / 2,
                  pA[1] + dy / 2 + dx * math.sqrt(3) / 2]
            self.kochCurve(order - 1, p1, pA)
            self.kochCurve(order - 1, pA, pC)
            self.kochCurve(order - 1, pC, pB)
            self.kochCurve(order - 1, pB, p2)

KochSnowflake() # Create GUI